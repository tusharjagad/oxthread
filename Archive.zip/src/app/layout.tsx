import type { Metadata } from 'next'
import './globals.css'
import { AuthProvider } from '@/contexts/auth-context'

export const metadata: Metadata = {
  title: 'OxThread — Self-Service Infrastructure Platform',
  description: 'A production-ready DevOps Self-Service Portal for automating PostgreSQL, CI/CD Pipelines, Azure Resources, and more.',
  keywords: ['DevOps', 'Self-Service', 'Azure', 'CI/CD', 'PostgreSQL', 'Infrastructure'],
  authors: [{ name: 'OxThread' }],
  robots: 'noindex, nofollow',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      </head>
      <body>
        <AuthProvider>
          {children}
        </AuthProvider>
      </body>
    </html>
  )
}
