import { NextRequest, NextResponse } from 'next/server'
import { requireAuth } from '@/lib/rbac'

export async function GET(request: NextRequest) {
  const auth = requireAuth(request)
  if (!auth.ok) return auth.response

  return NextResponse.json({
    user: {
      userId: auth.userId,
      username: auth.username,
      role: auth.role,
    },
  })
}
