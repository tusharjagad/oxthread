import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyPassword } from '@/lib/auth-utils'
import { createSession, setSessionCookie } from '@/lib/session'
import { createAuditLog, getIpFromRequest } from '@/lib/audit'

const MAX_FAILED = 6

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { accessKey, password } = body

    if (!accessKey || !password) {
      return NextResponse.json(
        { error: 'Access key and password are required' },
        { status: 400 }
      )
    }

    const user = await prisma.user.findUnique({ where: { accessKey } })

    if (!user) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    }

    if (!user.isActive) {
      return NextResponse.json({ error: 'Account is disabled' }, { status: 403 })
    }

    if (user.isLocked) {
      return NextResponse.json(
        { error: 'Account is locked due to too many failed attempts' },
        { status: 423 }
      )
    }

    if (user.expiry && user.expiry < new Date()) {
      return NextResponse.json({ error: 'Account has expired' }, { status: 403 })
    }

    const valid = await verifyPassword(password, user.passwordHash)

    if (!valid) {
      const failedLogins = user.failedLogins + 1
      const isLocked = failedLogins >= MAX_FAILED

      await prisma.user.update({
        where: { id: user.id },
        data: { failedLogins, isLocked },
      })

      await createAuditLog({
        userId: user.id,
        action: 'LOGIN_FAILED',
        resource: 'auth',
        ipAddress: getIpFromRequest(request),
        status: 'FAILURE',
        metadata: { failedAttempt: failedLogins },
      })

      if (isLocked) {
        return NextResponse.json(
          { error: 'Account locked after too many failed attempts' },
          { status: 423 }
        )
      }

      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    }

    // Reset failed logins on success
    await prisma.user.update({
      where: { id: user.id },
      data: { failedLogins: 0, lastLogin: new Date() },
    })

    // If TOTP is enabled, return a partial token
    if (user.totpEnabled) {
      const partialToken = await createSession({
        userId: user.id,
        username: user.username,
        role: user.role,
      })
      return NextResponse.json({ requireTotp: true, partialToken })
    }

    const token = await createSession({
      userId: user.id,
      username: user.username,
      role: user.role,
    })

    await setSessionCookie(token)

    await createAuditLog({
      userId: user.id,
      action: 'LOGIN_SUCCESS',
      resource: 'auth',
      ipAddress: getIpFromRequest(request),
      status: 'SUCCESS',
    })

    return NextResponse.json({
      success: true,
      user: { id: user.id, username: user.username, role: user.role },
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
