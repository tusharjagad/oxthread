'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  Plus, Search, RefreshCw, Database,
  Edit2, Trash2, ToggleLeft, ToggleRight, Key, X, Check,
} from 'lucide-react'
import { generateRandomPassword } from '@/lib/auth-utils'

interface PgUser {
  id: string
  username: string
  server: string
  databaseName: string
  role: string
  isActive: boolean
  expiry: string | null
  createdAt: string
}

const ROLES = ['READ_ONLY', 'READ_WRITE', 'ADMIN', 'BACKUP']
const ROLE_COLORS: Record<string, string> = {
  READ_ONLY:  'badge-info',
  READ_WRITE: 'badge-success',
  ADMIN:      'badge-purple',
  BACKUP:     'badge-warning',
}

function CreateUserModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [form, setForm] = useState({
    username: '', server: '', databaseName: '',
    role: 'READ_ONLY', password: '', expiry: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const generatePassword = () => {
    setForm((f) => ({ ...f, password: generateRandomPassword() }))
  }

  const submit = async () => {
    setError('')
    if (!form.username || !form.server || !form.databaseName) {
      setError('Username, server, and database are required')
      return
    }
    setLoading(true)
    const res = await fetch('/api/postgres-users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setLoading(false)
    if (!res.ok) { setError(data.error); return }
    onCreated()
    onClose()
  }

  return (
    <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h2 style={{ fontWeight: 700, fontSize: '1.05rem' }}>Create PostgreSQL User</h2>
          <button className="btn btn-icon btn-ghost" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {error && <div className="alert alert-error">{error}</div>}
          <div className="grid-2">
            <div className="form-group">
              <label className="form-label">Username *</label>
              <input className="form-input" value={form.username} onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))} placeholder="db_user_name" />
            </div>
            <div className="form-group">
              <label className="form-label">Database Server *</label>
              <input className="form-input" value={form.server} onChange={(e) => setForm((f) => ({ ...f, server: e.target.value }))} placeholder="postgres.example.com" />
            </div>
          </div>
          <div className="grid-2">
            <div className="form-group">
              <label className="form-label">Database Name *</label>
              <input className="form-input" value={form.databaseName} onChange={(e) => setForm((f) => ({ ...f, databaseName: e.target.value }))} placeholder="my_database" />
            </div>
            <div className="form-group">
              <label className="form-label">Role</label>
              <select className="form-select" value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}>
                {ROLES.map((r) => <option key={r}>{r}</option>)}
              </select>
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="flex gap-2">
              <input className="form-input font-mono" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} placeholder="Leave blank to auto-generate" />
              <button className="btn btn-secondary" onClick={generatePassword} title="Generate password"><Key size={15} /></button>
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Expiry Date (optional)</label>
            <input type="date" className="form-input" value={form.expiry} onChange={(e) => setForm((f) => ({ ...f, expiry: e.target.value }))} />
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={submit} disabled={loading}>
            {loading ? <span className="spinner" style={{ width: 14, height: 14 }} /> : <Check size={15} />}
            Create User
          </button>
        </div>
      </div>
    </div>
  )
}

export default function PostgreSQLPage() {
  const [users, setUsers] = useState<PgUser[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showCreate, setShowCreate] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    const res = await fetch(`/api/postgres-users?search=${encodeURIComponent(search)}`)
    const data = await res.json()
    setUsers(data.pgUsers || [])
    setTotal(data.total || 0)
    setLoading(false)
  }, [search])

  useEffect(() => { load() }, [load])

  const toggle = async (id: string, isActive: boolean) => {
    await fetch(`/api/postgres-users/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive: !isActive }),
    })
    load()
  }

  const remove = async (id: string, username: string) => {
    if (!confirm(`Delete user "${username}"?`)) return
    await fetch(`/api/postgres-users/${id}`, { method: 'DELETE' })
    load()
  }

  return (
    <div className="animate-fadein">
      {showCreate && <CreateUserModal onClose={() => setShowCreate(false)} onCreated={load} />}

      <div className="page-header">
        <div>
          <h1 className="page-title flex items-center gap-2">
            <Database size={24} style={{ color: 'var(--brand-blue)' }} /> PostgreSQL Users
          </h1>
          <p className="page-subtitle">{total} users across all database servers</p>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-secondary btn-sm" onClick={load}>
            <RefreshCw size={14} />
          </button>
          <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
            <Plus size={16} /> Create User
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="card mb-4">
        <div className="search-wrapper" style={{ maxWidth: 380 }}>
          <Search size={15} className="search-icon" />
          <input
            className="form-input search-input"
            placeholder="Search by username…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Table */}
      <div className="table-wrapper">
        <table className="table">
          <thead>
            <tr>
              <th>Username</th>
              <th>Database</th>
              <th>Server</th>
              <th>Role</th>
              <th>Status</th>
              <th>Created At</th>
              <th>Expiry</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  {Array.from({ length: 8 }).map((_, j) => (
                    <td key={j}><div style={{ height: 20, background: 'var(--bg-elevated)', borderRadius: 4, animation: 'pulse 1.5s infinite' }} /></td>
                  ))}
                </tr>
              ))
            ) : users.length === 0 ? (
              <tr>
                <td colSpan={8} style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
                  No PostgreSQL users found
                </td>
              </tr>
            ) : users.map((u) => (
              <tr key={u.id}>
                <td><span className="font-mono" style={{ fontSize: '0.85rem' }}>{u.username}</span></td>
                <td><span style={{ color: 'var(--text-secondary)' }}>{u.databaseName}</span></td>
                <td><span className="text-muted text-sm truncate" style={{ maxWidth: 150, display: 'block' }}>{u.server}</span></td>
                <td><span className={`badge ${ROLE_COLORS[u.role] || 'badge-muted'}`}>{u.role.replace('_', ' ')}</span></td>
                <td>
                  <span className={`badge ${u.isActive ? 'badge-success' : 'badge-muted'}`}>
                    {u.isActive ? 'Active' : 'Disabled'}
                  </span>
                </td>
                <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                  {new Date(u.createdAt).toLocaleDateString()}
                </td>
                <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                  {u.expiry ? new Date(u.expiry).toLocaleDateString() : '—'}
                </td>
                <td>
                  <div className="flex gap-1">
                    <button className="btn btn-icon btn-ghost" title={u.isActive ? 'Disable' : 'Enable'} onClick={() => toggle(u.id, u.isActive)}>
                      {u.isActive ? <ToggleRight size={16} style={{ color: 'var(--success)' }} /> : <ToggleLeft size={16} />}
                    </button>
                    <button className="btn btn-icon btn-danger" title="Delete" onClick={() => remove(u.id, u.username)}>
                      <Trash2 size={15} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
