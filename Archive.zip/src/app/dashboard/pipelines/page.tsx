'use client'

import { useState } from 'react'
import {
  GitBranch, Play, Copy, Download, Check,
  FileCode2, File, FileText, Cog, ChevronRight,
} from 'lucide-react'

const FRAMEWORKS = [
  { value: 'nextjs',   label: 'Next.js',  icon: '▲' },
  { value: 'react',    label: 'React',    icon: '⚛' },
  { value: 'nodejs',   label: 'Node.js',  icon: '🟢' },
  { value: 'python',   label: 'Python',   icon: '🐍' },
  { value: 'fastapi',  label: 'FastAPI',  icon: '⚡' },
]

const REGIONS = [
  'eastus', 'eastus2', 'westus', 'westus2', 'westus3',
  'centralus', 'northeurope', 'westeurope', 'southeastasia',
]

const FILE_ICONS: Record<string, React.ReactNode> = {
  'Dockerfile':                    <FileCode2 size={14} style={{ color: '#06b6d4' }} />,
  '.github/workflows/deploy.yml':  <GitBranch size={14} style={{ color: '#7c3aed' }} />,
  'deploy-aca.sh':                 <Cog size={14} style={{ color: '#f59e0b' }} />,
  '.env.template':                 <File size={14} style={{ color: '#10b981' }} />,
  'README.md':                     <FileText size={14} style={{ color: '#a78bfa' }} />,
}

export default function PipelinesPage() {
  const [form, setForm] = useState({
    appName: '', repoUrl: '', framework: 'nextjs',
    dockerfilePath: './Dockerfile', azureRegion: 'eastus', containerApp: '',
  })
  const [files, setFiles] = useState<Record<string, string> | null>(null)
  const [activeFile, setActiveFile] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }))

  const generate = async () => {
    setError('')
    if (!form.appName || !form.framework) { setError('App name and framework are required'); return }
    setLoading(true)
    const res = await fetch('/api/pipelines/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...form,
        containerApp: form.containerApp || form.appName.toLowerCase().replace(/[^a-z0-9-]/g, '-'),
      }),
    })
    const data = await res.json()
    setLoading(false)
    if (!res.ok) { setError(data.error); return }
    setFiles(data.files)
    setActiveFile(Object.keys(data.files)[0])
  }

  const copyContent = () => {
    if (!files || !activeFile) return
    navigator.clipboard.writeText(files[activeFile])
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const downloadAll = () => {
    if (!files) return
    Object.entries(files).forEach(([filename, content]) => {
      const blob = new Blob([content], { type: 'text/plain' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename.split('/').pop() || filename
      a.click()
      URL.revokeObjectURL(url)
    })
  }

  return (
    <div className="animate-fadein">
      <div className="page-header">
        <div>
          <h1 className="page-title flex items-center gap-2">
            <GitBranch size={24} style={{ color: 'var(--brand-purple-light)' }} /> CI/CD Pipeline Generator
          </h1>
          <p className="page-subtitle">Generate GitHub Actions, Dockerfile, and Azure Container Apps deployment scripts</p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '380px 1fr', gap: '1.25rem', alignItems: 'start' }}>
        {/* Config Form */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <h2 style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: '0.25rem' }}>Pipeline Configuration</h2>

          {error && <div className="alert alert-error">{error}</div>}

          <div className="form-group">
            <label className="form-label">Application Name *</label>
            <input className="form-input" value={form.appName} onChange={(e) => set('appName', e.target.value)} placeholder="my-app" />
          </div>

          <div className="form-group">
            <label className="form-label">Repository URL</label>
            <input className="form-input" value={form.repoUrl} onChange={(e) => set('repoUrl', e.target.value)} placeholder="https://github.com/org/repo" />
          </div>

          <div className="form-group">
            <label className="form-label">Framework *</label>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
              {FRAMEWORKS.map((fw) => (
                <button
                  key={fw.value}
                  onClick={() => set('framework', fw.value)}
                  style={{
                    padding: '0.625rem',
                    borderRadius: 8,
                    border: `1px solid ${form.framework === fw.value ? 'var(--brand-purple)' : 'var(--bg-border)'}`,
                    background: form.framework === fw.value ? 'rgba(124,58,237,0.15)' : 'var(--bg-elevated)',
                    color: form.framework === fw.value ? 'var(--brand-purple-light)' : 'var(--text-secondary)',
                    cursor: 'pointer',
                    fontSize: '0.85rem',
                    fontWeight: 500,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    transition: 'all 0.15s',
                  }}
                >
                  <span>{fw.icon}</span> {fw.label}
                </button>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Dockerfile Path</label>
            <input className="form-input font-mono" value={form.dockerfilePath} onChange={(e) => set('dockerfilePath', e.target.value)} placeholder="./Dockerfile" />
          </div>

          <div className="form-group">
            <label className="form-label">Azure Container App Name</label>
            <input className="form-input" value={form.containerApp} onChange={(e) => set('containerApp', e.target.value)} placeholder="auto-generated from app name" />
          </div>

          <div className="form-group">
            <label className="form-label">Azure Region</label>
            <select className="form-select" value={form.azureRegion} onChange={(e) => set('azureRegion', e.target.value)}>
              {REGIONS.map((r) => <option key={r}>{r}</option>)}
            </select>
          </div>

          <button
            className="btn btn-primary w-full"
            onClick={generate}
            disabled={loading}
            style={{ marginTop: '0.25rem' }}
          >
            {loading ? <span className="spinner" style={{ width: 16, height: 16 }} /> : <Play size={16} />}
            Generate Pipeline
          </button>
        </div>

        {/* Output Viewer */}
        {files ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {/* File list */}
            <div className="card" style={{ padding: '0.75rem' }}>
              <div className="flex items-center justify-between" style={{ marginBottom: '0.5rem' }}>
                <h3 style={{ fontWeight: 600, fontSize: '0.85rem', color: 'var(--text-muted)' }}>Generated Files</h3>
                <button className="btn btn-secondary btn-sm" onClick={downloadAll}>
                  <Download size={13} /> Download All
                </button>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {Object.keys(files).map((filename) => (
                  <button
                    key={filename}
                    onClick={() => setActiveFile(filename)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      padding: '0.35rem 0.75rem',
                      borderRadius: 6,
                      border: `1px solid ${activeFile === filename ? 'var(--brand-purple)' : 'var(--bg-border)'}`,
                      background: activeFile === filename ? 'rgba(124,58,237,0.15)' : 'var(--bg-elevated)',
                      color: activeFile === filename ? 'var(--brand-purple-light)' : 'var(--text-muted)',
                      fontSize: '0.8rem',
                      cursor: 'pointer',
                      transition: 'all 0.15s',
                    }}
                  >
                    {FILE_ICONS[filename] || <FileText size={14} />}
                    {filename.split('/').pop()}
                  </button>
                ))}
              </div>
            </div>

            {/* Code viewer */}
            <div className="code-block">
              <div className="code-block-header">
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{activeFile}</span>
                <button className="btn btn-secondary btn-sm" onClick={copyContent}>
                  {copied ? <Check size={13} style={{ color: 'var(--success)' }} /> : <Copy size={13} />}
                  {copied ? 'Copied!' : 'Copy'}
                </button>
              </div>
              <pre className="code-block-content">{files[activeFile]}</pre>
            </div>
          </div>
        ) : (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 400, gap: '1rem', color: 'var(--text-muted)' }}>
            <GitBranch size={48} style={{ opacity: 0.3 }} />
            <p style={{ fontSize: '0.9rem' }}>Fill in the form and click Generate Pipeline</p>
            <p style={{ fontSize: '0.8rem', opacity: 0.7 }}>Your Dockerfile, GitHub Actions workflow, and deployment scripts will appear here</p>
          </div>
        )}
      </div>
    </div>
  )
}
