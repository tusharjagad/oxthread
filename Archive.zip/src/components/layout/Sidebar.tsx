'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import {
  LayoutDashboard, Database, GitBranch, Cloud, Lock, ShieldCheck,
  ClipboardList, Users, Settings, Puzzle, Cog, ChevronDown,
} from 'lucide-react'

interface NavItem {
  label: string
  href: string
  icon: React.ReactNode
}

interface NavSection {
  title: string
  items: NavItem[]
}

const navigation: NavSection[] = [
  {
    title: 'Main',
    items: [
      { label: 'Dashboard', href: '/dashboard', icon: <LayoutDashboard size={16} /> },
    ],
  },
  {
    title: 'Services',
    items: [
      { label: 'PostgreSQL',      href: '/dashboard/postgresql',  icon: <Database size={16} /> },
      { label: 'CI/CD Pipelines', href: '/dashboard/pipelines',   icon: <GitBranch size={16} /> },
      { label: 'Azure Resources', href: '/dashboard/azure',       icon: <Cloud size={16} /> },
    ],
  },
  {
    title: 'Security',
    items: [
      { label: 'Secrets',        href: '/dashboard/secrets',        icon: <Lock size={16} /> },
      { label: 'Access Control', href: '/dashboard/access-control', icon: <ShieldCheck size={16} /> },
      { label: 'Audit Logs',     href: '/dashboard/audit-logs',     icon: <ClipboardList size={16} /> },
    ],
  },
  {
    title: 'Settings',
    items: [
      { label: 'Teams',           href: '/dashboard/teams',        icon: <Users size={16} /> },
      { label: 'Integrations',    href: '/dashboard/integrations', icon: <Puzzle size={16} /> },
      { label: 'System Settings', href: '/dashboard/settings',     icon: <Cog size={16} /> },
    ],
  },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="sidebar">
      {navigation.map((section) => (
        <div key={section.title} className="nav-section">
          <p className="nav-section-label">{section.title}</p>
          {section.items.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`nav-link ${isActive ? 'active' : ''}`}
              >
                <span style={{ color: isActive ? 'var(--brand-purple-light)' : 'var(--text-muted)' }}>
                  {item.icon}
                </span>
                {item.label}
              </Link>
            )
          })}
        </div>
      ))}

      {/* Footer */}
      <div style={{ padding: '1rem 0.75rem', marginTop: 'auto', borderTop: '1px solid var(--bg-border)' }}>
        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textAlign: 'center' }}>
          OxThread v1.0.0
        </div>
      </div>
    </aside>
  )
}
